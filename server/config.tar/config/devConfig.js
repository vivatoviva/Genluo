module.exports = {
  domain: 'http://localhost',
  // api进行缓存配置
  apiCache: {
    maxAge: 1000 * 3,
    isOpen: false,
  },
  // 缓存进行优化
  openUrlCache: false,
};
