module.exports = {
  domain: 'http://120.78.71.60',
  // api进行缓存配置
  apiCache: {
    maxAge: 1000 * 3,
    isOpen: true,
  },
  // 缓存进行优化
  openUrlCache: true,
  urlCache: {
    max: 100,
    maxAge: 1000 * 60 * 60, // 1hour
  },
};
