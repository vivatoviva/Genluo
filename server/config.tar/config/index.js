const isProduction = process.env.NODE_ENV === 'production';
const defaultConfig = require('./defaultConfig');
const productionConfig = require('./productionConfig');
const devConfig = require('./devConfig');

let config;
if (isProduction) {
  config = {
    ...defaultConfig,
    ...productionConfig,
  };
} else {
  config = {
    ...defaultConfig,
    ...devConfig,
  };
}
module.exports = config;